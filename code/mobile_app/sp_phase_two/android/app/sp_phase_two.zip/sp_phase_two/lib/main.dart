import 'package:connectivity/connectivity.dart';
import 'package:flutter/material.dart';
import 'package:bloc/bloc.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'package:spphasetwo/blocs/connection/bloc.dart' as Local;

//change to have an export file
import 'package:spphasetwo/ui/authenticate/sign_in_main.dart';
import 'package:provider/provider.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(
    StreamProvider<Local.ConnectionState>(
      create: (context) => Local.ConnectionBloc().connectionController.stream,
      child: Application(),
    ),

//    MultiBlocProvider(
//      providers: [
//        //Theme
//        //Authentication
//        //Settings?
////        BlocProvider<Local.ConnectionBloc>(
////          create: (context) => Local
////              .ConnectionBloc()..add(Local.ListenConnection()),
////        ),
//        BlocProvider<Local.ConnectionSecondBloc>(
//          create: (context) => Local.ConnectionSecondBloc(),
//        ),
//      ],
//      child: Application(),
//    ),
  );
}

class Application extends StatelessWidget {
  static bool _offlineActive = false;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      //Local.ConnectionBloc
      home: Scaffold(
        body: Builder(
          builder: (context) {
            var connectionStatus = Provider.of<Local.ConnectionState>(context);

            if (connectionStatus is Local.ConnectionOnline) {
              //return Container(child: Text("Onlineee"));
              SchedulerBinding.instance.addPostFrameCallback((_) {
                onlineSnackbar(context, _offlineActive);
              });
            } else if (connectionStatus is Local.ConnectionOffline) {
              SchedulerBinding.instance.addPostFrameCallback((_) {
                offlineSnackbar(context, _offlineActive);
              });
              //return Container(child: Text("Off"));
            }

            return SignInMain();
          },
        ),
//      home: Consumer<Local.ConnectionSecondBloc>(
//        builder: (context, state, child) {
//
//        },
//      ),
//      home: BlocBuilder<Local.ConnectionSecondBloc, Local.ConnectionSecondState>(
//        builder: (context, state) {
//          if (state is Local.ConnectionSecondOnline) {
//            print("onlineeeee");
//          }
//
//          if (state is Local.ConnectionSecondOffline) {
//            print("offlineeeqwqewq");
//          }
////          if (state is Local.ConnectionConnecting) {
////            //loadingDialog(context);
////            SchedulerBinding.instance.addPostFrameCallback((_) {
////              loadingDialog(context);
////            });
////          }
////
////          if (state is Local.ConnectionOnline) {
////            SchedulerBinding.instance.addPostFrameCallback((_) {
////              if (Navigator.of(context).canPop())
////                Navigator.of(context).pop();
////            });
////          }
////
////          if (state is Local.ConnectionOffline) {
////            //Change to something else (?)
////            SchedulerBinding.instance.addPostFrameCallback((_) {
////              if (Navigator.of(context).canPop())
////                Navigator.of(context).pop();
////
////              offlineDialog(context);
////            });
////          }
//
//          return SignInMain();
//        },
//      )
      ),
    );
  }
}

void onlineSnackbar(BuildContext context, bool offlineActive) {
  const onlineNotice = SnackBar(
    content: Text("Back online"),
  );

  if (offlineActive) {
    Scaffold.of(context).hideCurrentSnackBar();
    Scaffold.of(context).showSnackBar(onlineNotice);
    Scaffold.of(context).hideCurrentSnackBar();
  }
}

void offlineSnackbar(BuildContext context, bool offlineActive) {
  const offlineNotice = SnackBar(
    content: Text("Currently Offline"),
  );

  offlineActive = true;
  Scaffold.of(context).showSnackBar(offlineNotice);
}



// TODO: Place in a separate file
void loadingDialog(BuildContext parentContext) {
  showDialog(
      context: parentContext,
      builder: (BuildContext context) {
        // TODO: Make custom dialog
        return Dialog(
          backgroundColor: Colors.white,
          child: Container(
            padding: EdgeInsets.all(15.0),
            child: Row(
              children: <Widget>[
                CircularProgressIndicator(),
                SizedBox(width: 10.0),
                Text("Checking Connection"),
              ],
            ),
          ),
        );
      });
}

////Apply theme
//void offlineDialog(BuildContext parentContext) {
//  showDialog(
//      context: parentContext,
//      builder: (BuildContext context) {
//        // TODO: Make custom dialog
//        // Think about whether to allow user to exit dialog by tapping outside of bounds
//        return AlertDialog(
//          title: Text("Device Offline"),
//          content: SingleChildScrollView(
//            child: ListBody(
//              children: <Widget>[
//                Text("Looks like your device is offline."),
//                Text("Retry or switch to offline mode?"),
//              ],
//            ),
//          ),
//          actions: <Widget>[
//            FlatButton(
//                child: Text("Retry"),
//                onPressed: () {
//                  BlocProvider.of<Local.ConnectionBloc>(context)
//                      .add(Local.ListenConnection());
//                }),
//            FlatButton(child: Text("Switch to offline mode"), onPressed: () {}),
//          ],
//        );
//      }
//      );
//}
