import 'dart:async';
import 'package:bloc/bloc.dart';
import 'package:connectivity/connectivity.dart';
import './bloc.dart';

//put in repo
//import 'dart:io';
//import 'package:equatable/equatable.dart';
import 'package:data_connection_checker/data_connection_checker.dart';

class ConnectionBloc{

  StreamController<ConnectionState> connectionController = StreamController<ConnectionState>();

  ConnectionBloc() {
    var isDeviceConnected = false;

    // TODO: Test for connected to a network with no internet
    Connectivity().onConnectivityChanged.listen((ConnectivityResult res) async {
      if (res != ConnectivityResult.none) {
         isDeviceConnected = await DataConnectionChecker().hasConnection;

         if (isDeviceConnected)
           connectionController.add(ConnectionOnline());
         else
           connectionController.add(ConnectionOffline());
      } else {
        connectionController.add(ConnectionOffline());
      }
    });
  }

//  ConnectionSecondState _getStatus(ConnectivityResult res) {
//    ConnectionSecondState currState;
//
//    switch(res) {
//      case ConnectivityResult.wifi: return ConnectionSecondOnline();
//      case ConnectivityResult.mobile: return ConnectionSecondOnline();
//      case ConnectivityResult.none : return ConnectionSecondOffline();
//      default: return ConnectionSecondOffline();
//    }
//  }

//  Future<bool> _checkStatus() async {
//    try {
//      //Why is this here?
//      //Maybe place in a repo?
//
//      final res = await InternetAddress.lookup('google.com').timeout(const Duration(seconds: 3));
//      if (res.isNotEmpty && res[0].rawAddress.isNotEmpty)
//        return ConnectionSecondOnline();
//      else
//        return ConnectionOffline();
//
//    } on TimeoutException catch(_) {
//      //Throw when timeout is thrown, assume device is offline when ping fails
//      //for 5 seconds
//      return ConnectionSecondOffline();
//    } on SocketException catch(_) {
//      //Throw when device is not connected to a network
//      await new Future.delayed(const Duration(seconds: 10));
//      return ConnectionSecondOffline();
//    } catch(_) {
//      //Error is not caused by timeout, most likely error
//      //yield error instead of offline?
//      return ConnectionSecondOffline();
//    }
//  }
}

//class ConnectionBloc extends Bloc<ConnectionEvent, ConnectionState> {
//
//  @override
//  ConnectionState get initialState => ConnectionConnecting();
//
//  @override
//  Stream<ConnectionState> mapEventToState(ConnectionEvent event) async* {
//    // TODO: Add Logic
//    if (event is ListenConnection) {
//      yield* _mapListenConnectionToState();
//    }
//  }
//
//
//  Stream<ConnectionState> _mapListenConnectionToState() async* {
//
//    yield ConnectionConnecting();
//
//    try {
//      //Why is this here?
//      //Maybe place in a repo?
//
//      final res = await InternetAddress.lookup('google.com').timeout(const Duration(seconds: 5));
//      if (res.isNotEmpty && res[0].rawAddress.isNotEmpty)
//        yield ConnectionOnline();
//      else
//        yield ConnectionOffline();
//
//    } on TimeoutException catch(_) {
//      //Throw when timeout is thrown, assume device is offline when ping fails
//      //for 5 seconds
//      yield ConnectionOffline();
//    } on SocketException catch(_) {
//      //Throw when device is not connected to a network
//      await new Future.delayed(const Duration(seconds: 10));
//      yield ConnectionOffline();
//    } catch(_) {
//      //Error is not caused by timeout, most likely error
//      //yield error instead of offline?
//      yield ConnectionOffline();
//    }
//  }
//}
