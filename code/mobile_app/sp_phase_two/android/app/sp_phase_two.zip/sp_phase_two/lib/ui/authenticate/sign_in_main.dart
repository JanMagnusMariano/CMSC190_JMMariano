import 'package:flutter/material.dart';
import 'package:spphasetwo/styles/colors.dart';

//trial button
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:spphasetwo/blocs/connection/bloc.dart';

//change to accomodate auth bloc
class SignInMain extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: Container(
          width: MediaQuery.of(context).size.width,
          height: 45.0,
          child: FlatButton(
            color: Colors.red,
            child: Text("Ping"),
//            onPressed: () {
//              BlocProvider.of<ConnectionBloc>(context).add(ListenConnection());
//            },
          )
        )
      ),
    );
  }
}